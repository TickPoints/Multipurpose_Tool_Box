class RequestTimeoutError extends Error {
    constructor(message = "The request has exceeded the time limit.", code = -1) {
        super(message);
        this.name = "RequestTimeoutError";
        this.code = code;
    }
}

class InterfaceCallError extends Error {
    constructor(message, code = -1) {
        super(message);
        this.name = "InterfaceCallError";
        this.code = code;
    }
}

export {
    RequestTimeoutError,
    InterfaceCallError
}