import {
    system
}
from "@minecraft/server";

let funcs = [];

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id === "toolBroadcast:load") {
        for (let i of funcs) {
            i();
        };
    };
});

function listen(func) {
    funcs.push(func)
}

export {
    listen
}