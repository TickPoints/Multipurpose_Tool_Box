import * as tool from "../point.js";
import {
    DataReceive
}
from "./receiveData";

import {
    sendDataPack
}
from "./sendDataPack.js";

class InformationChain {
    id = "";
    uuid;
    callback = null;
    otherData = {};
    constructor(id = "", uuid = tool.generateUUID()) {
        this.id = id;
        this.uuid = uuid;
    };
    setCallback(id, func) {
        this.callback = {
            id: id,
            func: func
        };
    };
    setOtherData(data) {
        this.otherData = data;
    };
    load(pack, meta = {}, callback = this.callback) {
        meta.uuid = this.uuid;
        sendDataPack(this.id, pack, meta, this.otherData);
        if (callback === null) return;
        let data = new DataReceive(callback.id, this.uuid);
        data.setCallback(callback.func);
        return data;
    };
}

export {
    InformationChain
}