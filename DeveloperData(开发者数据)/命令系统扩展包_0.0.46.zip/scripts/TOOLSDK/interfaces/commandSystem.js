import {
    InformationChain
}
from "../InformationChain/InformationChain.js";
import {
    SDKSystem
}
from "../SDKSystem.js";

const commandSystem = {
    registr: function(commands) {
        let thisInterface = new InformationChain("toolAPI:commandSystem.registr");
        thisInterface = thisInterface.load({
            "commands": commands
        }, {
            "name": SDKSystem.name,
            "id": SDKSystem.id,
            "version": SDKSystem.version
        });
    }
};


export {
    commandSystem
}