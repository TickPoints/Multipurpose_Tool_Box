import {
    InformationChain
}
from "../InformationChain/InformationChain.js";
import {
    SDKSystem
}
from "../SDKSystem.js";
import * as tool from "../point.js";

const button = {
    GeneralTool: {
        add: function(buttonName, buttonImage, func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:button.GeneralTool.add", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid,
                "buttonName": buttonName,
                "buttonImage": buttonImage
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    OPTool: {
        add: function(buttonName, buttonImage, func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:button.OPTool.add", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid,
                "buttonName": buttonName,
                "buttonImage": buttonImage
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    Setting: {
        add: function(buttonName, buttonImage, func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:button.Setting.add", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid,
                "buttonName": buttonName,
                "buttonImage": buttonImage
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    }
};


export {
    button
}