import {
    InformationChain
}
from "../InformationChain/InformationChain.js";
import {
    SDKSystem
}
from "../SDKSystem.js";
import {
    system
}
from "@minecraft/server";
import {
    RequestTimeoutError
}
from "../Error.js";

function test(RequestCode) {
    let thisInterface = new InformationChain("toolAPI:test");
    thisInterface.setCallback("testResult", (data) => {});
    thisInterface = thisInterface.load({
        "RequestCode": RequestCode
    }, {
        "name": SDKSystem.name,
        "id": SDKSystem.id,
        "version": SDKSystem.version
    });
    if (RequestCode === 0) return;
    let time = 0;
    return new Promise(async (resolve) => {
        while (true) {
            let status = thisInterface.getStatus();
            if (status.status === true) {
                resolve(status.data.packData.result);
                return;
            }
            if (time > SDKSystem.RequestTimeLimit) {
                resolve(new RequestTimeoutError());
            }
            await system.waitTicks(1);
            time++;
        };
    });
};

export {
    test
}