import * as toolapi from "./TOOLSDK/index.js";

toolapi.broadcastResponse.load.listen(async () => {
    // 修改插件元数据名
    toolapi.SDKSystem.name = "开发者Easy";
    // 修改插件元数据ID
    toolapi.SDKSystem.id = "TickPoints.Easy";
    toolapi.SDKSystem.version.Plugin = "1.0.3";
    // 在一般工具中注册一个按钮
    toolapi.interface.button.GeneralTool.add("test", "", () => {
        console.warn("The button is pressed");
    });
    // 在命令系统中注册一个命令
    toolapi.interface.commandSystem.registr({
        "runGameCommand": {
            "type": "function",
            "run": function(performer, gameCommand) {
                try {
                    return JSON.stringify(performer.runCommand(gameCommand)); // @server/minecraft是已经导入好的环境量(具体值为mc)
                } catch {
                    return JSON.stringify(mc.world.getDimension("overworld").runCommand(gameCommand));
                };
            }.toString(),
            "config": {
                "parameters": [{
                    "type": "string"
                }],
                "RequiredPermission": 5,
                "needPermission": true
            }
        }
    });
    // 监听ToolUI的打开事件
    toolapi.interface.event.ToolUiShowed.listen(data => {
        console.warn("UI is open.");
    });
});