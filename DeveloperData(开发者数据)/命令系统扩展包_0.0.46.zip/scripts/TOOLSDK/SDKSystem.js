import {
    printErr
}
from "./point.js";

const SDKSystem = {
    name: "Unknown",
    id: "Unknown",
    RequestTimeLimit: 10,
    version: {
        "SDK": "0.0.7",
        "Plugin": "Unknown"
    },
    print: function(message, type = "Info") {
        printErr(message, type, SDKSystem.name);
    }
}

export {
    SDKSystem
}