import {
    InformationChain
}
from "../InformationChain/InformationChain.js";
import {
    SDKSystem
}
from "../SDKSystem.js";
import {
    RequestTimeoutError,
    InterfaceCallError
}
from "../Error.js";
import {
    system
}
from "@minecraft/server";

const System = {
    commandSystem: {
        registr: function(commands) {
            let thisInterface = new InformationChain("toolAPI:System.commandSystem.registr");
            thisInterface.setCallback("result", (data) => {});
            thisInterface = thisInterface.load({
                "commands": commands
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
            let time = 0;
            return new Promise(async (resolve) => {
                while (true) {
                    let status = thisInterface.getStatus();
                    if (status.status === true) {
                        let result = status.data.packData;
                        if (result.type === "Error") {
                            resolve(new InterfaceCallError(result.message, result.code))
                        } else {
                            resolve(true);
                        };
                        return;
                    }
                    if (time > SDKSystem.RequestTimeLimit) {
                        resolve(new RequestTimeoutError());
                    }
                    await system.waitTicks(1);
                    time++;
                };
            });
        },
        translationMap: {
            add: function(id, value) {
                let thisInterface = new InformationChain("toolAPI:System.commandSystem.translationMap.add");
                thisInterface.setCallback("result", (data) => {});
                thisInterface = thisInterface.load({
                    "id": id,
                    "value": value
                }, {
                    "name": SDKSystem.name,
                    "id": SDKSystem.id,
                    "version": SDKSystem.version
                });
                let time = 0;
                return new Promise(async (resolve) => {
                    while (true) {
                        let status = thisInterface.getStatus();
                        if (status.status === true) {
                            let result = status.data.packData;
                            if (result.type === "Error") {
                                resolve(new InterfaceCallError(result.message, result.code))
                            } else {
                                resolve(true);
                            };
                            return;
                        }
                        if (time > SDKSystem.RequestTimeLimit) {
                            resolve(new RequestTimeoutError());
                        }
                        await system.waitTicks(1);
                        time++;
                    };
                });
            },
            set: function(value) {
                let thisInterface = new InformationChain("toolAPI:System.commandSystem.translationMap.set");
                thisInterface.setCallback("result", (data) => {});
                thisInterface = thisInterface.load({
                    "value": value
                }, {
                    "name": SDKSystem.name,
                    "id": SDKSystem.id,
                    "version": SDKSystem.version
                });
                let time = 0;
                return new Promise(async (resolve) => {
                    while (true) {
                        let status = thisInterface.getStatus();
                        if (status.status === true) {
                            let result = status.data.packData;
                            if (result.type === "Error") {
                                resolve(new InterfaceCallError(result.message, result.code))
                            } else {
                                resolve(true);
                            };
                            return;
                        }
                        if (time > SDKSystem.RequestTimeLimit) {
                            resolve(new RequestTimeoutError());
                        }
                        await system.waitTicks(1);
                        time++;
                    };
                });
            }
        }
    },
    config: {
        get: function(path) {
            let thisInterface = new InformationChain("toolAPI:System.config.get");
            thisInterface.setCallback("configData", (data) => {});
            thisInterface = thisInterface.load({
                "path": path
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
            let time = 0;
            return new Promise(async (resolve) => {
                while (true) {
                    let status = thisInterface.getStatus();
                    if (status.status === true) {
                        let result = status.data.packData.result;
                        resolve(result);
                        return;
                    }
                    if (time > SDKSystem.RequestTimeLimit) {
                        resolve(new RequestTimeoutError());
                    }
                    await system.waitTicks(1);
                    time++;
                };
            });
        },
        set: function(path, value) {
            let thisInterface = new InformationChain("toolAPI:System.config.set");
                thisInterface.setCallback("result", (data) => {});
                thisInterface = thisInterface.load({
                    "value": value,
                    "path": path
                }, {
                    "name": SDKSystem.name,
                    "id": SDKSystem.id,
                    "version": SDKSystem.version
                });
                let time = 0;
                return new Promise(async (resolve) => {
                    while (true) {
                        let status = thisInterface.getStatus();
                        if (status.status === true) {
                            let result = status.data.packData;
                            if (result.type === "Error") {
                                resolve(new InterfaceCallError(result.message, result.code))
                            } else {
                                resolve(true);
                            };
                            return;
                        }
                        if (time > SDKSystem.RequestTimeLimit) {
                            resolve(new RequestTimeoutError());
                        }
                        await system.waitTicks(1);
                        time++;
                    };
                });
        }
    }
};

export {
    System
}