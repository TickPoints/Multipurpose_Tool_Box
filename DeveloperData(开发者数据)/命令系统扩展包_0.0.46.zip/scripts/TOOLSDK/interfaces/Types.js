const UITypes = {
    about: "aboutUi",
    tool: "toolUi",
    opTool: "OPToolUi",
    setting: "settingUi",
    inputCommand: "commandSystemUi",
    userDocumentation: "UDUi"
}

export {
    UITypes
}