import {
    InformationChain
}
from "../InformationChain/InformationChain.js";
import {
    SDKSystem
}
from "../SDKSystem.js";

const ui = {
    show: function(player, UIName) {
        let thisInterface = new InformationChain("toolAPI:ui.show");
        thisInterface = thisInterface.load({
            "triggerName": player.name,
            "uiName": UIName
        }, {
            "name": SDKSystem.name,
            "id": SDKSystem.id,
            "version": SDKSystem.version
        });
    }
};

export {
    ui
}