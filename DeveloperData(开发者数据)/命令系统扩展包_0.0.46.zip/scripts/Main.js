import * as toolapi from "./TOOLSDK/index.js";
import * as tool from "./TOOLSDK/point.js";
import {
    DataReceive
}
from "./TOOLSDK/InformationChain/receiveData.js";


toolapi.broadcastResponse.initialize.listen(async () => {
    toolapi.SDKSystem.name = "命令系统扩展";
    toolapi.SDKSystem.id = "TickPoints.CommandSystemExtension";
    let SystemPluginsMap = tool.getData("SystemPluginsMap");
    if (SystemPluginsMap === null) {
        tool.saveData("SystemPluginsMap", []);
        SystemPluginsMap = [];
    }
    let config = await toolapi.interface.System.config.get("systemPlugins");
    if (config instanceof Error) {
        toolapi.SDKSystem.print(`请授予 ${toolapi.SDKSystem.id} 权限`, "Error");
        return;
    }
    for (let i of SystemPluginsMap) {
        if (!(i in config)) config.push(i);
    }
    await toolapi.interface.System.config.set("systemPlugins", config);
    let dataReceive = new DataReceive("add", toolapi.SDKSystem.id);
    dataReceive.setCallback(data => {
        SystemPluginsMap = tool.getData("SystemPluginsMap");
        SystemPluginsMap.push(data.id);
        tool.saveData("SystemPluginsMap", SystemPluginsMap);
    });
    let dataReceive2 = new DataReceive("clear", toolapi.SDKSystem.id);
    dataReceive2.setCallback(data => {
        tool.saveData("SystemPluginsMap", []);
    });
});

toolapi.broadcastResponse.load.listen(async () => {
    toolapi.interface.System.commandSystem.registr(commands);
    toolapi.interface.System.commandSystem.translationMap.add("\\S", " ");
});

const commands = {
    "runGameCommand": {
        "type": "function",
        "run": function(performer, gameCommand) {
            try {
                return JSON.stringify(performer.runCommand(gameCommand));
            } catch {
                return JSON.stringify(mc.world.getDimension("overworld").runCommand(gameCommand));
            };
        }.toString(),
        "config": {
            "parameters": [{
                "type": "string"
            }],
            "RequiredPermission": 5,
            "needPermission": true
        }
    },
    "addSystemPlugin": {
        "type": "function",
        "run": function(performer, id) {
            import("interfaces.js").then(models => {
                models.sendDataPack("TickPoints.CommandSystemExtension:add", {
                    "id": id
                });
                tool.printErr(`SystemPlugin ${id} 添加成功，/reload后起效`, "Info", "addSystemPlugin");
            });
        }.toString(),
        "config": {
            "parameters": [{
                "type": "string"
            }],
            "RequiredPermission": 5,
            "needPermission": true
        }
    },
    "clearAllSystemPlugins": {
        "type": "function",
        "run": function(performer) {
            import("interfaces.js").then(models => {
                models.sendDataPack("TickPoints.CommandSystemExtension:clear", {});
                tool.printErr(`SystemPlugin已清空，/reload后起效`, "Info", "clearSystemPlugins");
            });
        }.toString(),
        "config": {
            "RequiredPermission": 5,
            "needPermission": true
        }
    },
    "subscribe": {
        "type": "subcommand",
        "subcommand": {
            "afterEvents": {
                "type": "subcommand",
                "subcommand": {
                    "entityDie": {
                        "type": "function",
                        "run": function(un, index, command) {
                            interpreter.unsubscribe.data.entityDie[index] = function(eventData) {
                                let deadEntity = eventData.deadEntity;
                                let com = command.replace("&deadEntity", deadEntity.id);
                                com = com.replace("&cause", damageEntity.cause);
                                com = command.replace("&deadEntityNameTag", deadEntity.nameTag);
                                com = command.replace("&damagingEntity", damageEntity.damagingEntity.id);
                                com = command.replace("&damagingProjectile", damageEntity.damagingProjectile.id);
                                runcmd(un, com);
                            };
                            mc.world.afterEvents.entityDie.subscribe(interpreter.unsubscribe.data.entityDie[index]);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "int",
                                "translation": true
                            }, {
                                "type": "string"
                            }],
                            "RequiredPermission": 5,
                            "needPermission": true
                        }
                    }
                }
            },
            "beforeEvents": {
                "type": "subcommand",
                "subcommand": {}
            }
        }
    },
    "unsubscribe": {
        "type": "function",
        "run": function(un, index, eventName) {

        }.toString(),
        "config": {
            "parameters": [{
                "type": "int",
                "translation": true
            }],
            "RequiredPermission": 5,
            "needPermission": true
        },
        "data": []
    },
    "sendMessage": {
        "type": "function",
        "run": function(un, message, target = mc.world) {
            target.sendMessage(message);
        }.toString(),
        "config": {
            "parameters": [{
                "type": "string"
            }, {
                "type": "entity",
                "requirement": "select",
                "translation": true
            }],
            "RequiredPermission": 3,
            "needPermission": true
        }
    },
    "gameData": {
        "type": "subcommand",
        "subcommand": {
            "get": {
                "type": "subcommand",
                "subcommand": {
                    "gamerule": {
                        "type": "function",
                        "run": function(un, gamerule) {
                            return mc.world.gameRules[gamerule];
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "string"
                            }],
                            "RequiredPermission": 3,
                            "needPermission": true
                        }
                    },
                    "playerLocation": {
                        "type": "function",
                        "run": function(un, player) {
                            return JSON.stringify(player.location);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "player",
                                "translation": true
                            }],
                            "RequiredPermission": 3,
                            "needPermission": true
                        }
                    },
                    "temp": {
                        "type": "function",
                        "run": function(un, id) {
                            let temp = interpreter.gameData.temp;
                            return JSON.stringify(temp[id]);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "string"
                            }],
                            "RequiredPermission": 3,
                            "needPermission": true
                        }
                    }
                }
            },
            "set": {
                "type": "subcommand",
                "subcommand": {
                    "gamerule": {
                        "type": "function",
                        "run": function(un, gamerule, value) {
                            mc.world.gameRules[gamerule] = value;
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "string"
                            }, {
                                "type": "adaptation",
                                "translation": true
                            }],
                            "RequiredPermission": 5,
                            "needPermission": true
                        }
                    },
                    "temp": {
                        "type": "function",
                        "run": function(un, id, value) {
                            let temp = interpreter.gameData.temp;
                            temp[id] = value;
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "string"
                            }, {
                                "type": "adaptation",
                                "translation": true
                            }],
                            "RequiredPermission": 3,
                            "needPermission": true
                        }
                    }
                }
            }
        },
        "temp": {}
    },
    "math": {
        "type": "subcommand",
        "subcommand": {
            "add": {
                "type": "function",
                "run": function(Invalidity, number1, number2) {
                    return number1 + number2;
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "number",
                        "translation": true
                    }]
                }
            },
            "reduce": {
                "type": "function",
                "run": function(Invalidity, number1, number2) {
                    return number1 - number2;
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "number",
                        "translation": true
                    }]
                }
            },
            "multiply": {
                "type": "function",
                "run": function(Invalidity, number1, number2) {
                    return number1 * number2;
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "number",
                        "translation": true
                    }]
                }
            },
            "divided": {
                "type": "function",
                "run": function(Invalidity, number1, number2) {
                    return number1 / number2;
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "number",
                        "translation": true
                    }]
                }
            },
            "equal": {
                "type": "function",
                "run": function(Invalidity, number1, number2) {
                    return number1 === number2;
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "number",
                        "translation": true
                    }]
                }
            },
            "isTrue": {
                "type": "function",
                "run": function(performer, value, message, elseMessage) {
                    if (value) {
                        return message
                    } else {
                        return elseMessage;
                    };
                }.toString()
            },
            "negation": {
                "type": "function",
                "run": function(Invalidity, value) {
                    return !value;
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "boolean",
                        "translation": true
                    }]
                }
            }
        }
    },
    "for": {
        "type": "subcommand",
        "subcommand": {
            "in": {
                "type": "function",
                "run": function(performer, list, command) {
                    for (let index of list) {
                        runcmd(performer, command.replace(/&index/g, JSON.stringify(index)));
                    };
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "json",
                        "translation": true
                    }, {
                        "type": "string"
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "reach": {
                "type": "function",
                "run": function(performer, value, command) {
                    for (let index = 0; index < value; index++) {
                        runcmd(performer, command.replace(/&index/g, index));
                    }
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "int",
                        "translation": true
                    }, {
                        "type": "string"
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            }
        }
    },
    "run": {
        "type": "function",
        "run": function(performer, ...commands) {
            for (let i of commands) runcmd(performer, i);
        }.toString()
    },
    "json": {
        "type": "subcommand",
        "subcommand": {
            "dict": {
                "type": "subcommand",
                "subcommand": {
                    "setChild": {
                        "type": "function",
                        "run": function(un, json, id, value) {
                            json[id] = value;
                            return JSON.stringify(json);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "json",
                                "translation": true
                            }, {
                                "type": "string"
                            }, {
                                "type": "adaptation",
                                "translation": true
                            }],
                            "RequiredPermission": 2,
                            "needPermission": true
                        }
                    },
                    "getChild": {
                        "type": "function",
                        "run": function(un, json, id) {
                            return JSON.stringify(json[id]);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "json",
                                "translation": true
                            }, {
                                "type": "string"
                            }],
                            "RequiredPermission": 2,
                            "needPermission": true
                        }
                    }
                }
            },
            "list": {
                "type": "subcommand",
                "subcommand": {
                    "setChild": {
                        "type": "function",
                        "run": function(un, list, index, value) {
                            list[index] = value;
                            return JSON.stringify(list);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "json",
                                "translation": true
                            }, {
                                "type": "int"
                            }, {
                                "type": "adaptation",
                                "translation": true
                            }],
                            "RequiredPermission": 2,
                            "needPermission": true
                        }
                    },
                    "getChild": {
                        "type": "function",
                        "run": function(un, list, index) {
                            return JSON.stringify(list[index]);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "json",
                                "translation": true
                            }, {
                                "type": "int"
                            }],
                            "RequiredPermission": 2,
                            "needPermission": true
                        }
                    },
                    "addChild": {
                        "type": "function",
                        "run": function(un, list, value) {
                            list.push(value);
                            return JSON.stringify(list);
                        }.toString(),
                        "config": {
                            "parameters": [{
                                "type": "json",
                                "translation": true
                            }, {
                                "type": "adaptation",
                                "translation": true
                            }],
                            "RequiredPermission": 2,
                            "needPermission": true
                        }
                    }
                }
            }
        }
    },
    "superMath": {
        "type": "subcommand",
        "subcommand": {
            "random": {
                "type": "function",
                "run": function(un) {
                    return Math.random();
                }.toString(),
                "config": {
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "approximate": {
                "type": "function",
                "run": function(un, num, digit = 2, mode = 0) {
                    switch (mode) {
                        case 0:
                            return num.toFixed(digit);
                        case 1:
                            return Math.floor(num * Math.pow(10, digit));
                        case 2:
                            return Math.ceil(num / Math.pow(10, digit)) * Math.pow(10, digit);
                        default:
                            console.error(`Type of error: ${mode}`);
                            return null;
                    }
                }.toString(),
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "int",
                        "translation": true,
                        "requirement": "select"
                    }, {
                        "type": "int",
                        "translation": true,
                        "requirement": "select"
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "sqrt": { // 数字的平方根
                "type": "function",
                "run": "function(un, num) {return Math.sqrt(num);}",
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "cos": { // 数字的余弦值
                "type": "function",
                "run": "function(un, num) {return Math.cos(num);}",
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "log": { // 数字的自然对数值
                "type": "function",
                "run": "function(un, num) {return Math.log(num);}",
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "pow": { // num1的num2次幂
                "type": "function",
                "run": "function(un, num1, num2) {return Math.pow(num1, num2);}",
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }, {
                        "type": "number",
                        "translation": true
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "tan": { // 数字的正切值
                "type": "function",
                "run": "function(un, num) {return Math.tan(num);}",
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            },
            "sin": { // 数字的正弦值
                "type": "function",
                "run": "function(un, num) {return Math.sin(num);}",
                "config": {
                    "parameters": [{
                        "type": "number",
                        "translation": true
                    }],
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            }
        }
    },
    "MATH_CONSTANT_POOL": {
        "type": "function",
        "run": function(un, id) {
            return Math[id];
        }.toString(),
        "config": {
            "parameters": [{
                "type": "enumeration",
                "enumeration": ["E", "LN2", "LN10", "LOG2E", "LOG10E", "PI", "SORT1_2", "SQRT2"]
            }],
            "RequiredPermission": 2,
            "needPermission": true
        }
    },
    "string": {
        "type": "subcommand",
        "subcommand": {
            "translationf": {
                "type": "function",
                "run": function(un, string, ...replaceString) {
                    return tool.translationf(string, ...replaceString);
                },
                "config": {
                    "RequiredPermission": 2,
                    "needPermission": true
                }
            }
        }
    }
};