import {
    InformationChain
}
from "../InformationChain/InformationChain.js";
import {
    SDKSystem
}
from "../SDKSystem.js";
import * as tool from "../point.js";

const event = {
    aboutUiShowed: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.aboutUiShowed.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    commandReg: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.commandReg.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    menuUiShowed: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.menuUiShowed.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    OPToolUiShowed: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.OPToolUiShowed.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    SettingUiShowed: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.SettingUiShowed.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    ToolUiShowed: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.ToolUiShowed.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    },
    UDUiShowed: {
        listen: function(func) {
            const uuid = tool.generateUUID();
            let thisInterface = new InformationChain("toolAPI:event.UDUiShowed.listen", uuid);
            thisInterface.setCallback("callback", func);
            thisInterface = thisInterface.load({
                "callbackId": uuid
            }, {
                "name": SDKSystem.name,
                "id": SDKSystem.id,
                "version": SDKSystem.version
            });
        }
    }
};

export {
    event
}